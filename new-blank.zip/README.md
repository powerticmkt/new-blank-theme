# new-blank-theme

Tema sem nenhum layout para ser utilizado no Mautic

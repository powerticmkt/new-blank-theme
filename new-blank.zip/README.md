# new-blank-theme

Tema sem nenhum layout para ser utilizado no Mautic

Faça o download https://raw.githubusercontent.com/powerticmkt/new-blank-theme/master/new-blank.zip
